
export class User{
  publicUid:string;
  email: string;
  firstname: string;
  // lastname: string;
  role:string;
  token: string;
  id: number;
}
