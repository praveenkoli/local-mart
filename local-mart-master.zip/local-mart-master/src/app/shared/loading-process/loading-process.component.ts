import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loading-process',
  templateUrl: './loading-process.component.html',
  styleUrls: ['./loading-process.component.css']
})
export class LoadingProcessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
