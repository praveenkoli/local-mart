package com.rspatil45.first_project.service;




import com.rspatil45.first_project.shared.dto.UserDto;

public interface UserService {
	//UserDto createdService(UserDto user);

	UserDto createUser(UserDto user) ;
	
		

}
